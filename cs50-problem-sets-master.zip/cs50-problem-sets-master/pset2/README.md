# Problem set 2

Source: [Link](https://docs.cs50.net/2018/x/psets/2/pset2.html "Problem set 2")

## Tasks

* [Caesar, less comfortable](/pset2/caesar/README.md "Caesar, less comfortable");
* [Vigenère, less comfortable](/pset2/vigenere/README.md "Vigenère, less comfortable");
* [Crack, more comfortable](/pset2/crack/README.md "Crack, more comfortable");
* Extra task see in `/pset2/extra`.

## Prepare

Run commands in console:
```
$ cd
$ mkdir pset2
$ cd pset2
```

[Back to main](/README.md "Back to main")
