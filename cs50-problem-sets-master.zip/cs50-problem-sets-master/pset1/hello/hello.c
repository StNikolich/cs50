#include <stdio.h>

int main(void)
{
    // Say `hello, world`
    printf("hello, world\n");
}