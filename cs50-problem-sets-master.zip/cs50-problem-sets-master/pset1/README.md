# Problem set 1

Source: [Link](https://docs.cs50.net/2018/x/psets/1/pset1.html "Problem set 1")

## Tasks

* [Hello](/pset1/hello/README.md "Hello");
* [Mario, less comfortable](/pset1/mario/README.md "Mario, less comfortable");
* [Mario, more comfortable](/pset1/mario/README.md "Mario, more comfortable");
* [Cash, less comfortable](/pset1/cash/README.md "Cash, less comfortable");
* [Credit, more comfortable](/pset1/credit/README.md "Credit, more comfortable");
* Extra task see in `/pset1/extra`.

## Prepare

Run commands in console:
```
$ cd
$ mkdir pset1
$ cd pset1
```

[Back to main](/README.md "Back to main")
